<div id="contenedor0" class="contenedor0">
    <div id="contenedor1" class="contenedor1">
        <form id="formConsulta1" class="bloque1">
            <input type="text" id="textoConsulta1" name="textoConsulta1" required class="campo1">
            <input type="submit" id="botonConsulta1" name="botonConsulta1" value="Buscar" class="boton1">
            <input type="button" id="botonConsulta2" name="botonConsulta2" value="Ver todo" class="boton1">
        </form>
    </div>
    <div id="contenedor2" class="contenedor2"></div>
</div>