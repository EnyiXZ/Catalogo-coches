document.addEventListener('DOMContentLoaded', function() {
    const contenedor = document.getElementById('contenedor0');


    const numElementos = parseInt(prompt("¿Cuántos elementos deseas crear?"));
    const tipoElemento = prompt("¿Qué tipo de elemento deseas crear? (div, p, span, img)").toLowerCase();

    // FUNCION PARA CRER EL ELEMENTO QUE SE PIDA 
    function crearElemento(tipo) {
        const elemento = document.createElement(tipo);

    
        if (tipo === 'img') 
            { 
            elemento.src = 'img/l1.png';//RITA DE LA IMAGEN 
            } 
        else if (tipo === 'div') 
            {
                elemento.textContent = 'Este es un div';
            } 
        else if (tipo === 'p') 
            {
                elemento.textContent = 'Este es un párrafo';
            } 
        else if (tipo === 'span') 
            {
                elemento.textContent = 'Este es un span';
            }

        return elemento;
    }

   //FUNCION PARA METR EL CSS
    function aplicarPropiedadesCSS(elemento, tipo)
    {

        //AQUI MIRAMOS SI ES UNA IMAGEN EN VEZ DE CAMBIAR COLOR DE LETRA Y FONDO CAMBIAMOS TAMAÑOS
        if (tipo === 'img')
             {
  
            const width = prompt("Introduce el ancho de la imagen (en píxeles, ej: 200)");
            const height = prompt("Introduce la altura de la imagen (en píxeles, ej: 150)");
            if (width) {
                elemento.style.width = `${width}px`;
            }
            if (height) {
                elemento.style.height = `${height}px`;
            }

            } 
        else 
            {
                // CAMBIAMOS EL COLOR DE TEXTO Y FONDO 
            const color = prompt("Introduce el color del texto (ej: red)");
            const backgroundColor = prompt("Introduce el color de fondo (ej: blue)");
            if (color) {
                elemento.style.color = color;
            }
            if (backgroundColor) {
                elemento.style.backgroundColor = backgroundColor;
            }
            }
    }

    //FUNCION PARA AGREGAR EL LEEMENTO A LA PAGINA
    function pintarElemento(elemento) {
        contenedor.appendChild(elemento);
    }

    function borrarElemento() {
        const deseaEliminar = confirm("¿Deseas eliminar un elemento?"); 
        if (deseaEliminar) { 
            const etiqueta = prompt("Introduce la etiqueta del elemento a eliminar (ej: div, p, span, img)");
             const elementos = document.querySelectorAll(etiqueta); 
             
             if (elementos.length > 0) { elementos[0].parentNode.removeChild(elementos[0]); }
            else { alert("No se encontró ningún elemento con esa etiqueta."); } 
        }
    }
    // SE CREA LA CANTIDAD DE ELEMENTOS QUE SE PIDEN
    for (let i = 0; i < numElementos; i++) {
        const nuevoElemento = crearElemento(tipoElemento);
        aplicarPropiedadesCSS(nuevoElemento, tipoElemento);
        pintarElemento(nuevoElemento);
    }
    
    setTimeout(borrarElemento, 5000);
});
