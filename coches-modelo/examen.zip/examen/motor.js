//EJERCICIO EXAMEN PARTE 1

const numeros = {
    a: ['1', '2', '3', '4', '5', '6', '7', '9', '10']
};
const numerosasc = {
    b: ['1', '22', '13', '4', '325', '36', '73', '9', '120']
};
//ej1
function mostrarNumeros(array) {
    console.log(array.join(', '));
}

//ej2
function calcularSuma(array) {
    return array.reduce((suma, valorActual) => suma + parseInt(valorActual), 0);
}

//ej3
function encontrarMayor(array) {
    let mayor = Number(array[0]);
    for (let i = 1; i < array.length; i++) {
        if (Number(array[i]) > mayor) {
            mayor = Number(array[i]);
        }
    }
    return mayor;
}

//ej4
function filtrarPares(array) {
     return array.map(Number).filter(num => num % 2 === 0); 
}

//ej5
function multiplicarPor(array, numero) {
    return array.map(num => Number(num) * numero);
}

//ej6
function ordenarAscendente(array) { 
    return array.slice().sort((a, b) => Number(a) - Number(b)); 
}

const valores = numeros['a'];


//ej1
mostrarNumeros(valores);

//DEJO LA ALERTA COMENTADA PORQUE CHOCA CON EL CODIGO
//alert(valores.join(', '));

//ej2
const suma = calcularSuma(valores);
console.log(`La suma es: ${suma}`);

//ej3
const mayor = encontrarMayor(valores);
console.log(`El número mayor es: ${mayor}`);

//ej4
const pares = filtrarPares(valores);
console.log(`Los números pares son: ${pares.join(', ')}`);

//ej5
const valorMultiplicacion = 2;
const multiplicados = multiplicarPor(valores, valorMultiplicacion);
console.log(`Los números multiplicados por ${valorMultiplicacion} son: ${multiplicados.join(', ')}`);
//ej6
const ascendente = numerosasc['b']; 
const valoresOrdenados = ordenarAscendente(ascendente);
console.log(`Los números en orden ascendente son: ${valoresOrdenados.join(', ')}`);



// EJERCICIO EXAMEN PARTE 2

document.addEventListener('DOMContentLoaded', function() {

    alert("el índice empieza desde el 0");

    const contenedor = document.getElementById('contenedor0');

    // CREATE ELEMENT PARA EL NOMBRE 
    const inputNombre = document.createElement('input');
    inputNombre.setAttribute('type', 'text');
    inputNombre.setAttribute('placeholder', 'Nombre');
    contenedor.appendChild(inputNombre);

    // CREATE ELEMENT PARA LA EDAD
    const inputEdad = document.createElement('input');
    inputEdad.setAttribute('type', 'number');
    inputEdad.setAttribute('placeholder', 'Edad');
    contenedor.appendChild(inputEdad);

    // CREATE ELEMENT PARA EL BOTON DE AÑADIR LOS NOMBRES Y LAS EDADES
    const botonAgregar = document.createElement('button');
    botonAgregar.textContent = 'Agregar';
    contenedor.appendChild(botonAgregar);

    // CREATE ELEMENT PARA EL INDICE FUNCIONES DE ACTUALIZAR Y ELIMINAR LOS NOMBRES/EDADES
    const inputIndice = document.createElement('input');
    inputIndice.setAttribute('type', 'number');
    inputIndice.setAttribute('placeholder', 'Índice para actualizar/eliminar');
    contenedor.appendChild(inputIndice);

    // CREATE ELEMENT PARA ACTUALIZAR EL NOMBRE
    const inputNuevoNombre = document.createElement('input');
    inputNuevoNombre.setAttribute('type', 'text');
    inputNuevoNombre.setAttribute('placeholder', 'Nuevo Nombre');
    contenedor.appendChild(inputNuevoNombre);

    // CREATE ELEMENT PARA ACTUALIZAR LA EDAD
    const inputNuevaEdad = document.createElement('input');
    inputNuevaEdad.setAttribute('type', 'number');
    inputNuevaEdad.setAttribute('placeholder', 'Nueva Edad');
    contenedor.appendChild(inputNuevaEdad);

    // CREATE ELEMENT PARA BOTON QUE ACTUALICE EL NOMBRE/EDAD
    const botonActualizar = document.createElement('button');
    botonActualizar.textContent = 'Actualizar';
    contenedor.appendChild(botonActualizar);

    // CREATE ELEMENT PARA BOTON QUE ELIMINA EL NOMBRE/EDAD
    const botonEliminar = document.createElement('button');
    botonEliminar.textContent = 'Eliminar';
    contenedor.appendChild(botonEliminar);

    // CREATE ELEMENT PARA LA LISTA DESORDENADA
    const lista = document.createElement('ul');
    contenedor.appendChild(lista);

    // FUNCION QUE AGREGA EL NOMBRE Y LA EDAD A LA LISTA
    function agregarElemento(nombre, edad) {
        const itemLista = document.createElement('li');
        itemLista.textContent = `Nombre: ${nombre}, Edad: ${edad}`;
        lista.appendChild(itemLista);
        //CONTADOR DE ELEMENTOS REVISA CUANTOS HAY
        console.log(`Cantidad total de elementos: ${contarElementos()}`);
    }

    // FUNCION QUE DA UTILIDAD AL BOTON DE ELIMINAR
    function eliminarElemento(indice) {
        if (lista && lista.children[indice]) {
            lista.removeChild(lista.children[indice]);
        //CONTADOR DE ELEMENTOS REVISA CUANTOS HAY
            console.log(`Cantidad total de elementos: ${contarElementos()}`);
        } else {
            alert('Índice inválido.');
        }
    }

    // FUNCION PARA ACTUALIZAR EL CONTENIDO DE NOMBRE Y EDAD
    function actualizarContenido(indice, nuevoNombre, nuevaEdad) {
        if (lista && lista.children[indice]) {
            const itemLista = lista.children[indice];
            itemLista.textContent = `Nombre: ${nuevoNombre}, Edad: ${nuevaEdad}`;
            //CONTADOR DE ELEMENTOS REVISA CUANTOS HAY
            console.log(`Cantidad total de elementos: ${contarElementos()}`);
        } else {
            alert('Índice inválido.');
        }
    }

    // FUNCION PARA CONTAR ELEMENTOS EN LA LISTA
    function contarElementos() {
        return lista.children.length;
    }

    // FUNCIONALIDAD AL BOTON DE AGREGAR (AÑADE LOS NOMBRES Y EDADES)
    botonAgregar.addEventListener('click', function() {
        const nombre = inputNombre.value;
        const edad = inputEdad.value;

        if (nombre && edad) {
            agregarElemento(nombre, edad);
            inputNombre.value = '';
            inputEdad.value = '';
        } else {
            alert('Por favor, introduce ambos campos: nombre y edad.');
        }
    });

    // FUNCIONALIDAD AL BOTON DE ACTUALIZAR (AÑADE LOS NUEVOS NOMBRES Y NUEVAS EDADES)
    botonActualizar.addEventListener('click', function() {
        const indice = parseInt(inputIndice.value);
        const nuevoNombre = inputNuevoNombre.value;
        const nuevaEdad = inputNuevaEdad.value;

        if (!isNaN(indice) && nuevoNombre && nuevaEdad) {
            actualizarContenido(indice, nuevoNombre, nuevaEdad);
            inputIndice.value = '';
            inputNuevoNombre.value = '';
            inputNuevaEdad.value = '';
        } else {
            alert('Por favor, introduce todos los campos correctamente.');
        }
    });

    // FUNCIONALIDAD AL BOTON DE ELIMINAR (ELIMINA UN ELEMENTO DE LA LISTA POR SU INDICE)
    botonEliminar.addEventListener('click', function() {
        const indice = parseInt(inputIndice.value);

        if (!isNaN(indice)) {
            eliminarElemento(indice);
            inputIndice.value = '';
        } else {
            alert('Por favor, introduce un índice válido.');
        }
    });
});
